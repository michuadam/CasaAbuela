import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useCart } from "@/hooks/use-cart";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Navbar } from "@/components/Navbar";
import { ArrowLeft, MapPin, Package, User, Building2 } from "lucide-react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { toast } from "sonner";

declare global {
  interface Window {
    easyPackAsyncInit?: () => void;
    easyPack?: any;
  }
}

export default function Checkout() {
  const [, setLocation] = useLocation();
  const { cartItems, cartTotal } = useCart();
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [selectedPoint, setSelectedPoint] = useState<any>(null);
  const [geowidgetLoaded, setGeowidgetLoaded] = useState(false);
  
  const [customerType, setCustomerType] = useState<"individual" | "company">("individual");
  const [formData, setFormData] = useState({
    customerName: "",
    customerEmail: "",
    customerPhone: "",
    companyName: "",
    companyNip: "",
  });

  // Pre-fill form with user data if logged in
  useEffect(() => {
    if (isAuthenticated && user) {
      const userData = user as any;
      setFormData(prev => ({
        ...prev,
        customerName: userData.firstName && userData.lastName 
          ? `${userData.firstName} ${userData.lastName}`.trim() 
          : prev.customerName,
        customerEmail: userData.email || prev.customerEmail,
      }));
    }
  }, [isAuthenticated, user]);

  useEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://sandbox-global-geowidget-sdk.easypack24.net/inpost-geowidget.js';
    script.async = true;
    document.body.appendChild(script);

    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = 'https://sandbox-global-geowidget-sdk.easypack24.net/inpost-geowidget.css';
    document.head.appendChild(link);

    script.onload = () => {
      setGeowidgetLoaded(true);
    };

    return () => {
      document.body.removeChild(script);
      document.head.removeChild(link);
    };
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const openGeowidget = () => {
    if (window.easyPack) {
      window.easyPack.modalMap((point: any) => {
        setSelectedPoint(point);
      }, { width: 500, height: 600 });
    } else {
      const modal = document.createElement('div');
      modal.id = 'inpost-geowidget-modal';
      modal.innerHTML = `
        <div style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 9999; display: flex; align-items: center; justify-content: center;">
          <div style="background: white; width: 90%; max-width: 800px; height: 80%; border-radius: 8px; overflow: hidden; position: relative;">
            <button onclick="this.parentElement.parentElement.remove()" style="position: absolute; top: 10px; right: 10px; z-index: 10; background: #333; color: white; border: none; border-radius: 50%; width: 30px; height: 30px; cursor: pointer;">×</button>
            <inpost-geowidget 
              onpointselect="window.handleInpostPoint" 
              token="eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJkVzROZW9TeXk0OHpCOHg4emdZX2t5dFNiWHY3blZ0eFVGVFpzWV9TUFA4In0.eyJleHAiOjIwODEyODYzNDgsImlhdCI6MTc2NTkyNjM0OCwianRpIjoiMzUxNTg0MGItZGU0ZS00NTQxLWFlNzEtYzJhYmE3NDkzMGEzIiwiaXNzIjoiaHR0cHM6Ly9zYW5kYm94LWxvZ2luLmlucG9zdC5wbC9hdXRoL3JlYWxtcy9leHRlcm5hbCIsInN1YiI6ImY6N2ZiZjQxYmEtYTEzZC00MGQzLTk1ZjYtOThhMmIxYmFlNjdiOnBmdmlGR3B5NWxWdF9kOXZtUEFKcE5OQVpWTFV4VUJ0SFlHMk5nUHNWQnciLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJzaGlweCIsInNlc3Npb25fc3RhdGUiOiIyNWVlZjFkMS01NzczLTQzNDItOGFjNS1iZGM1NjQzZjFlNjYiLCJzY29wZSI6Im9wZW5pZCBhcGk6YXBpcG9pbnRzIiwic2lkIjoiMjVlZWYxZDEtNTc3My00MzQyLThhYzUtYmRjNTY0M2YxZTY2IiwiYWxsb3dlZF9yZWZlcnJlcnMiOiJhYnVlbGEuY2FzYSIsInV1aWQiOiI3YjM5ODYzNi1kOTJiLTQ3YTUtYmU1OC00MzRlMzZlZDFkZWQifQ.iISdU9h8mHn0n-D0YWB417zaAIHh6qhUOhSvlkg-_xqpPBUFEoGB9dK23KZzc1u5CU3yvQ1gp3bzqDqgYstxcFNTJ9YS9WLCNTfyZtfXkpoWbyUQHme9VCjFSpSD6iCOPeA41dpzoczfXLy1Qhw8HpY6eBvM485-04wbb66aE-ofA-9lATIhx18vA6wd8abIKHYk1B0B-JfvsyWJpyhNK6GYfZxy7KoUsRfG4n_aU63bSxYfqvM1I-_3dvUzRUOKVNthOLDEtaaGgzAFadfS37ZW5mWk5KOQvTc8EeWKj--tmsvMb5xvfaOFK5N7kMU_LvnELCvPXf5dLebcvmO4qQ"
              country="PL"
              language="pl"
              config="parcelcollect"
            ></inpost-geowidget>
          </div>
        </div>
      `;
      document.body.appendChild(modal);
      
      (window as any).handleInpostPoint = (point: any) => {
        setSelectedPoint(point.detail);
        modal.remove();
      };
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.customerName || !formData.customerEmail || !formData.customerPhone) {
      toast.error("Proszę wypełnić wszystkie pola");
      return;
    }

    if (customerType === "company" && (!formData.companyName || !formData.companyNip)) {
      toast.error("Proszę wypełnić dane firmy");
      return;
    }

    if (!selectedPoint) {
      toast.error("Proszę wybrać paczkomat");
      return;
    }

    setIsLoading(true);
    
    try {
      const response = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...formData,
          customerType,
          inpostPointId: selectedPoint.name,
          inpostPointName: selectedPoint.address?.line1 || selectedPoint.name,
          inpostPointAddress: `${selectedPoint.address?.line1 || ''}, ${selectedPoint.address?.line2 || ''}`,
        }),
      });

      const data = await response.json();
      
      if (data.url) {
        window.location.href = data.url;
      } else {
        toast.error(data.error || "Nie udało się utworzyć sesji płatności");
      }
    } catch (error) {
      toast.error("Wystąpił błąd podczas przetwarzania zamówienia");
    } finally {
      setIsLoading(false);
    }
  };

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-[#F9F7F2]">
        <Navbar />
        <div className="container mx-auto px-4 pt-32 pb-16 text-center">
          <h1 className="font-serif text-3xl text-primary mb-4">Twój koszyk jest pusty</h1>
          <p className="text-muted-foreground mb-8">Dodaj produkty do koszyka, aby kontynuować</p>
          <Button onClick={() => setLocation("/")} className="bg-primary hover:bg-primary/90">
            Wróć do sklepu
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F9F7F2]">
      <Navbar />
      <div className="container mx-auto px-4 pt-32 pb-16">
        <Button 
          variant="ghost" 
          onClick={() => setLocation("/")}
          className="mb-8 text-primary hover:text-primary/80"
          data-testid="button-back"
        >
          <ArrowLeft className="mr-2 h-4 w-4" /> Powrót do sklepu
        </Button>

        <div className="grid lg:grid-cols-2 gap-12">
          <div className="space-y-8">
            <div>
              <h1 className="font-serif text-3xl text-primary mb-2">Dane do wysyłki</h1>
              <p className="text-muted-foreground">Wypełnij formularz, aby kontynuować</p>
            </div>

            {!isAuthenticated && (
              <div className="bg-white border border-stone-200 rounded-lg p-6">
                <div className="flex items-center gap-3 mb-3">
                  <User className="h-5 w-5 text-primary" />
                  <h3 className="font-serif text-lg text-primary">Masz konto?</h3>
                </div>
                <p className="text-sm text-muted-foreground mb-4">
                  Zaloguj się, aby automatycznie wypełnić dane i śledzić historię zamówień.
                </p>
                <Button 
                  type="button"
                  variant="outline"
                  onClick={() => window.location.href = '/login'}
                  className="w-full"
                  data-testid="button-checkout-login"
                >
                  Zaloguj się lub utwórz konto
                </Button>
              </div>
            )}

            {isAuthenticated && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center">
                    {(user as any)?.profileImageUrl ? (
                      <img 
                        src={(user as any).profileImageUrl} 
                        alt="Profil" 
                        className="h-10 w-10 rounded-full object-cover"
                      />
                    ) : (
                      <User className="h-5 w-5 text-green-600" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium text-green-800">Zalogowano jako</p>
                    <p className="text-sm text-green-600">{(user as any)?.email}</p>
                  </div>
                </div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-4">
                <div className="bg-white border border-stone-200 rounded-lg p-4">
                  <Label className="text-base font-medium mb-3 block">Typ klienta</Label>
                  <RadioGroup 
                    value={customerType} 
                    onValueChange={(v) => setCustomerType(v as "individual" | "company")}
                    className="flex gap-4"
                  >
                    <label 
                      htmlFor="individual"
                      className={`flex-1 flex items-center gap-3 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                        customerType === "individual" 
                          ? "border-primary bg-primary/5" 
                          : "border-stone-200 hover:border-stone-300"
                      }`}
                      data-testid="radio-individual"
                    >
                      <RadioGroupItem value="individual" id="individual" />
                      <div>
                        <span className="font-medium">
                          <User className="h-4 w-4 inline mr-2" />
                          Osoba fizyczna
                        </span>
                        <p className="text-xs text-muted-foreground mt-1">Paragon fiskalny</p>
                      </div>
                    </label>
                    <label 
                      htmlFor="company"
                      className={`flex-1 flex items-center gap-3 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                        customerType === "company" 
                          ? "border-primary bg-primary/5" 
                          : "border-stone-200 hover:border-stone-300"
                      }`}
                      data-testid="radio-company"
                    >
                      <RadioGroupItem value="company" id="company" />
                      <div>
                        <span className="font-medium">
                          <Building2 className="h-4 w-4 inline mr-2" />
                          Firma
                        </span>
                        <p className="text-xs text-muted-foreground mt-1">Faktura VAT</p>
                      </div>
                    </label>
                  </RadioGroup>
                </div>

                {customerType === "company" && (
                  <div className="bg-stone-50 border border-stone-200 rounded-lg p-4 space-y-4">
                    <h3 className="font-medium text-primary flex items-center gap-2">
                      <Building2 className="h-4 w-4" />
                      Dane firmy
                    </h3>
                    <div>
                      <Label htmlFor="companyName">Nazwa firmy</Label>
                      <Input
                        id="companyName"
                        name="companyName"
                        value={formData.companyName}
                        onChange={handleInputChange}
                        placeholder="Nazwa Sp. z o.o."
                        className="mt-1"
                        data-testid="input-company-name"
                      />
                    </div>
                    <div>
                      <Label htmlFor="companyNip">NIP</Label>
                      <Input
                        id="companyNip"
                        name="companyNip"
                        value={formData.companyNip}
                        onChange={handleInputChange}
                        placeholder="1234567890"
                        className="mt-1"
                        data-testid="input-company-nip"
                      />
                    </div>
                  </div>
                )}

                <div>
                  <Label htmlFor="customerName">Imię i nazwisko</Label>
                  <Input
                    id="customerName"
                    name="customerName"
                    value={formData.customerName}
                    onChange={handleInputChange}
                    placeholder="Jan Kowalski"
                    className="mt-1"
                    data-testid="input-customer-name"
                  />
                </div>

                <div>
                  <Label htmlFor="customerEmail">Email</Label>
                  <Input
                    id="customerEmail"
                    name="customerEmail"
                    type="email"
                    value={formData.customerEmail}
                    onChange={handleInputChange}
                    placeholder="jan@example.com"
                    className="mt-1"
                    data-testid="input-customer-email"
                  />
                </div>

                <div>
                  <Label htmlFor="customerPhone">Telefon</Label>
                  <Input
                    id="customerPhone"
                    name="customerPhone"
                    type="tel"
                    value={formData.customerPhone}
                    onChange={handleInputChange}
                    placeholder="+48 123 456 789"
                    className="mt-1"
                    data-testid="input-customer-phone"
                  />
                </div>
              </div>

              <div className="border-t pt-6">
                <h2 className="font-serif text-xl text-primary mb-4 flex items-center gap-2">
                  <Package className="h-5 w-5" />
                  Punkt odbioru InPost
                </h2>
                
                {selectedPoint ? (
                  <div className="bg-white p-4 rounded-lg border border-stone-200 mb-4">
                    <div className="flex items-start gap-3">
                      <MapPin className="h-5 w-5 text-primary mt-1" />
                      <div>
                        <p className="font-medium text-primary">{selectedPoint.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {selectedPoint.address?.line1}, {selectedPoint.address?.line2}
                        </p>
                      </div>
                    </div>
                    <Button 
                      type="button"
                      variant="outline" 
                      onClick={openGeowidget}
                      className="mt-3 w-full"
                      data-testid="button-change-point"
                    >
                      Zmień paczkomat
                    </Button>
                  </div>
                ) : (
                  <Button 
                    type="button"
                    variant="outline" 
                    onClick={openGeowidget}
                    className="w-full h-20 border-dashed"
                    data-testid="button-select-point"
                  >
                    <MapPin className="mr-2 h-5 w-5" />
                    Wybierz paczkomat
                  </Button>
                )}
              </div>

              <Button 
                type="submit"
                disabled={isLoading || !selectedPoint}
                className="w-full h-14 bg-primary hover:bg-primary/90 text-white uppercase tracking-widest"
                data-testid="button-pay"
              >
                {isLoading ? "Przetwarzanie..." : `Zapłać ${(cartTotal + 14.99).toFixed(2)} PLN`}
              </Button>
            </form>
          </div>

          <div className="lg:pl-8 lg:border-l border-stone-200">
            <h2 className="font-serif text-xl text-primary mb-6">Podsumowanie zamówienia</h2>
            
            <div className="space-y-4 mb-6">
              {cartItems.map((item: any) => (
                <div key={item.id} className="flex gap-4 py-3 border-b border-stone-100">
                  <div className="w-16 h-16 bg-white rounded flex items-center justify-center flex-shrink-0">
                    <img 
                      src="/Gemini_Generated_Image_49qvov49qvov49qv_1765237897906.png" 
                      alt={item.product?.title}
                      className="w-full h-full object-contain p-1"
                    />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-primary">{item.product?.title} {item.product?.weight}</p>
                    <p className="text-sm text-muted-foreground">Ilość: {item.quantity}</p>
                  </div>
                  <p className="font-medium text-primary">
                    {(parseFloat(item.product?.price || '0') * item.quantity).toFixed(2)} PLN
                  </p>
                </div>
              ))}
            </div>

            <div className="space-y-3 pt-4 border-t border-stone-200">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Produkty</span>
                <span className="text-primary">{cartTotal.toFixed(2)} PLN</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Dostawa (InPost)</span>
                <span className="text-primary">14.99 PLN</span>
              </div>
              <div className="flex justify-between text-lg font-medium pt-3 border-t border-stone-200">
                <span className="text-primary">Razem</span>
                <span className="text-primary">{(cartTotal + 14.99).toFixed(2)} PLN</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
